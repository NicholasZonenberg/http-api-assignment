The code that I created is in:
src/htmlResponse.html

To launch the webpage:
npm start

To view the output:
open src/output.txt

Function to handle getting indexes of substrings (used from stack exchange):
getIndicesOf

Code written to handle taking in the txt to usable data (custom):
processJSON

Code written to process the data into the output (custom):
getData